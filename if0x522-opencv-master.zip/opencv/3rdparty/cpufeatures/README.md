The Android NDK provides a small library named cpufeatures that your app can use at runtime to detect the target device's CPU family and the optional features it supports.
It is designed to work as-is on all official Android platform versions.

https://developer.android.com/ndk/guides/cpu-features.html
